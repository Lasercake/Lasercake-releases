// This file is necessary because bcp gets confused by some of Boost's
// preprocessor magic (#include SOME_MACRO_NAME()) and fails to copy
// certain necessary files that we list here.

#include <boost/typeof/incr_registration_group.hpp>

